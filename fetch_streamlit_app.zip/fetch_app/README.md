# Fetch — Video Downloader

A modern Streamlit web app for downloading videos from YouTube, TikTok, Instagram, Facebook, X/Twitter, and more.

## Run locally

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Deploy to Streamlit Community Cloud

1. Push this folder to a GitHub repository
2. Go to [share.streamlit.io](https://share.streamlit.io)
3. Click **New app** → select your repo → set main file to `app.py`
4. Deploy — `packages.txt` automatically installs FFmpeg on the server

## Files

| File | Purpose |
|------|---------|
| `app.py` | Main Streamlit application |
| `requirements.txt` | Python dependencies |
| `packages.txt` | System packages (FFmpeg) — used by Streamlit Cloud |

## Notes

- **TikTok**: Downloads without watermark by default
- **Instagram / Facebook**: Public posts only. Private content requires cookie auth (not supported in this app)
- **FFmpeg**: Required for MP3 extraction and merging HD video+audio streams. Installed automatically on Streamlit Cloud via `packages.txt`
- Downloaded files are served via Streamlit's `st.download_button` — files are held in server memory, not stored permanently
